import { DBManager } from "./DBManager";

export class Storage {
    static instance: Storage;

    public static getInstance(): Storage {
        !Storage.instance && (Storage.instance = new Storage());

        return Storage.instance;
    }

    private constructor() { }

    //user 1 is the sender, user 2 is the receiver
    public async saveMsg(user1: string, user2: string, msg: string, time = new Date().toISOString()) {
        try {
            //sql insert statement
            const sqlInsertMessageQuery = "INSERT INTO messages (user1, user2, msg, date_time) VALUES ($1, $2, $3, $4)";

            await DBManager.getInstance().executeInsertConsult(sqlInsertMessageQuery, [user1, user2, msg, time]);

            const sqlSelectLastMessageQuery = `
                SELECT msgId
                FROM messages
                WHERE user1 = $1 AND user2 = $2
                ORDER BY id DESC
                LIMIT 1
            `;

            return await DBManager.getInstance().executeSelectConsult(sqlSelectLastMessageQuery, [user1, user2]);
        } catch (error) {
            console.log(error);

            throw error;
        }

    }

    public async getAllMsgs(user1: string, user2: string, lastIndex?: number) {
        try {
            //sql select statement
            const sqlSelectAllMessagesQuery = `
            SELECT *
            FROM messages
            WHERE (user1 = $1 AND user2 = $2) OR (user1 = $2 AND user2 = $1) ${lastIndex && "AND id > $3"}
            ORDER BY date_time DESC
            `;

            return await DBManager.getInstance().executeSelectConsult(sqlSelectAllMessagesQuery, [user1, user2, lastIndex]);
        } catch (error) {
            console.log(error);

            throw error;
        }
    }
}
