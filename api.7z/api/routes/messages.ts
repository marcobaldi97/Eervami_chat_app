import express from "express";
import { Storage } from "../core/Storage" //todo: from here

export = () => {
	const messagesRouter = express.Router();

	messagesRouter.post("/sendMsg", async function (req, res, next) {
		try {
			const { from, to, message } = req.body;

			const idFromMsg = await Storage.getInstance().saveMsg(from, to, message);

			res.send("Saved message, last id: " + idFromMsg);
		} catch (error) {
			res.status(500).send(error);
		}
	});
}
